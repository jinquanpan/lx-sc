<template>
    <footer class="foot_col1">
    <div class="foot_col row mx-0 ">
        <div class="col-xl-1"></div>
        <div class="col-lg-2 col-sm-12 px-0 foot_left">
            <div class="row mx-0 mx-0">
                <div class="col-xl-12 box  px-0 logopro  d-flex pt-5 py-5 logo_col">
                    <img src="img/773313593239136406.png" alt="" class="logopro ">
                    <div>
                    <div class="text_col h4 my-0 ">神策数据</div>
                    <div class="text_col d-block logo_size">SENSORS Data</div>
                    </div>
                </div>
                
                <div class="col-xl-12  logo_col px-0 ">
                    <div class="">Tel: 400-650-9827</div>
                    <div class="mt_-4">E-mail: contact@sensorsdata.cn</div>
                    <img src="img/qr252_57e4a83.png" class="gzh mt-2" alt="">
                    <div class="mt-1">关注公众号</div>
                    <div>©2019神策数据京IPC备15055677号</div>
                    <div ><img src="img/website_filling_d0289dc.jpg" class="gh" alt="">
                    京公网安备11010802027887号
                    </div>
                </div>
        </div>
    </div>
        
        <div class="offset-xl-1 col-lg-6 col-sm-12 px-0 px-0 w-100">
            <div class="row mx-0 foot_body ">
                <div class="col-lg-2 col-md-4 logo_col foot_size pt-5 pr-0 pl-0 text-center">
                    <div class="text-white pt-4 h5">产品</div>
                    <div class="border-top mt-2"></div>
                    <div class="mt-2"><a href="#">数据基础能力</a></div>
                    <div class="mt-2"><a href="#">数据采集</a></div>
                    <div class="mt-2"><a href="#">PaaS</a></div>
                    <div class="mt-2"><a href="#">私有化部署</a></div>
                </div>
                <div class="col-lg-2 col-md-4 logo_col foot_size pt-5 px-0 text-center">
                        <div class="text-white pt-4 h5">&nbsp;</div>
                        <div class="border-top mt-2"></div>
                        <div class="mt-2"><a href="#">数据应用产品</a></div>
                        <div class="mt-2"><a href="#">神策分析</a></div>
                        <div class="mt-2"><a href="#">神策用户画像</a></div>
                        <div class="mt-2"><a href="#">神策智能运营</a></div>
                        <div class="mt-2"><a href="#">神策智能推荐</a></div>
                        <div class="mt-2"><a href="#">神策客景</a></div>
                    </div>
                    <div class="col-lg-2 col-md-4 logo_col foot_size pt-5 px-0 text-center">
                        <div class="text-white pt-4 h5">解决方案</div>
                        <div class="border-top mt-2"></div>
                        <div class="mt-2"><a href="#">互联网金融</a></div>
                        <div class="mt-2"><a href="#">电子商务</a></div>
                        <div class="mt-2"><a href="#">证券</a></div>
                        <div class="mt-2"><a href="#">零售</a></div>
                        </div>
                    <div class="col-lg-2 col-md-4 logo_col foot_size pt-5 px-0 text-center">
                        <div class="text-white pt-4 h5">用户中心</div>
                        <div class="border-top mt-2"></div>
                        <div class="mt-2"><a href="#">客户服务</a></div>
                        <div class="mt-2"><a href="#">使用手册</a></div>
                        <div class="mt-2"><a href="#">技术文档</a></div>
                        <div class="mt-2"><a href="#">视频学习</a></div>
                        <div class="mt-2"><a href="#">GitHub</a></div>
                        </div>
                    <div class="col-lg-2 col-md-4 logo_col foot_size pt-5 px-0 text-center">
                        <div class="text-white pt-4 h5">关于我们</div>
                        <div class="border-top mt-2"></div>
                        <div class="mt-2"><a href="#">公司介绍</a></div>
                        <div class="mt-2"><a href="#">公司动态</a></div>
                        <div class="mt-2"><a href="#">专家团队</a></div>
                        <div class="mt-2"><a href="#">加入我们</a></div>
                        <div class="mt-2"><a href="#">合作伙伴计划</a></div>
                        <div class="mt-2"><a href="#">联系我们</a></div>
                        </div>
                    <div class="col-lg-2 col-md-4 logo_col foot_size pt-5 px-0 pr-0 text-center">
                        <div class="text-white pt-4 h5">神策图书馆</div>
                        <div class="border-top mt-2"></div>
                        <div class="mt-2"><a href="javascript:">产品学习专区</a></div>
                        <div class="mt-2"><a href="javascript:">资源图书馆</a></div>
                        <div class="mt-2"><a href="javascript:">老客户专区</a></div>
                        <div class="mt-2"><a href="javascript:">博客文章</a></div>
                        <div class="mt-2"><a href="javascript:">体验DEMO</a></div>
                        </div>
            </div>
        </div>
    </div>
    </footer>
</template>
<script>
export default {
    
}
</script>
<style scoped>
    .foot_col{background:#2f3939;height:394px;}
    .foot_col1{background:#2f3939;position: relative}
    .logopro{height: 44px}
    .logo_col{color:#a6a9ab}
    .logo_size{margin-top:-5px;}
    .mt_-5{margin-top:-5px}
    .mt_-4{margin-top:-4px}
    .mt_-3{margin-top:-3px}
    .mt_-2{margin-top:-2px}
    .gzh{width: 144px;}
    *{font-family: "宋体"}
    .foot_size{font-size: 18px;}
    a{text-decoration:none;color:#a6a9ab}
    a:hover{text-decoration:none;color:#a6a9ab}
    .gh{width:20px;}
    .foot_body{min-width:690px;}
    .foot_left{min-width:255px}
</style>